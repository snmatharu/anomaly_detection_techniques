# Changelog
All notable changes to this project will be documented in this file.

## [v1.1] - 2019-09-12
### Updated runtime to Python 3
- Moved python 2 runtimes into independent detectors.
- Updated documentation and examples.

## [v1.0] - 2017-04-26
### Initial release
- Established proper python program setup.

## [v0.8] - 2015-09-04
### Initial tag for scoreboard