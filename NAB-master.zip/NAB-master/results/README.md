These are the raw results CSV files reflecting NAB v1.0.
Please see the [Scoreboard](https://github.com/numenta/NAB/#scoreboard) in the main README.
